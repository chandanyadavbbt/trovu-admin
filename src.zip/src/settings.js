// Settings.js
import React from 'react';

const settings = () => {
  return (
    <div>
      <h1>Settings Page</h1>
      {/* Add your settings content here */}
    </div>
  );
}

export default settings;
